import Vue from 'vue'
import element from 'element-ui'
import locale from 'element-ui/lib/locale/lang/zh-CN'

Vue.use(element, {locale})
