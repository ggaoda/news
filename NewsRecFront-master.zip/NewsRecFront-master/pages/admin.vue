<template>
  <div style="width:100%;height: 100%">
    <nuxt-child></nuxt-child>
  </div>
</template>

<script>
export default {
  name: "admin"
}
</script>

<style scoped>

</style>
