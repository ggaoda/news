<template>
  <v-app class="back">
    <nuxt/>
  </v-app>
</template>

<script>
  export default {
    name: "index",
  }
</script>

<style scoped>
  .back {
    background-color: white;
  }
</style>
