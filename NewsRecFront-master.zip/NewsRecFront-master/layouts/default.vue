<template>
  <v-app class="back">
    <nuxt style="z-index: 1"/>
  </v-app>
</template>

<script>

  export default {
  }
</script>
<style scoped>
  .back {

    position: relative;
  }

</style>
